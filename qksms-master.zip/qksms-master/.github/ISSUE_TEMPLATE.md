### DESCRIPTION
A short description of the issue. 
Example: Conversations aren't marked as read when they are opened from a notification.

### STEPS
1. Steps
2. to 
3. reproduce
4. the 
5. issue.

### EXPECTED
Describe the expected behaviour.

### OBSERVATIONS
Describe what happens instead of the expected behaviour.

